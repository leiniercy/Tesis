package com.example.application.data;

public enum Role {
    USER, ADMIN;
}
